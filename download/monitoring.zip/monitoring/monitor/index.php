	<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
	<title>Smart Energy Monitoring Location:EE Building.</title>
	<script src="http://code.jquery.com/jquery-2.0.0.js"></script>
	<script src="http://code.jquery.com/jquery-migrate-1.1.1.js"></script>
	<link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.red-orange.min.css" />
	 <script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
	    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="js/update.js"></script>
</head>
<body>

<!-- Always shows a header, even in smaller screens. -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
  <header class="mdl-layout__header">
    <div class="mdl-layout__header-row">
      <!-- Title -->
      <span class="mdl-layout-title">Smart Energy Monitoring Location:EE Building.</span>
      <!-- Add spacer, to align navigation to the right -->
      <div class="mdl-layout-spacer"></div>
      <!-- Navigation. We hide it in small screens. -->
      <nav class="mdl-navigation mdl-layout--large-screen-only">
      <a class="mdl-button mdl-js-button mdl-js-ripple-effect" style = "color:#FFFFFF;" href="logs.php">Logs view</a>
      </nav>
    </div>
  </header>
  <div class="mdl-layout__drawer">
    <span class="mdl-layout-title" style="background-color:#DD2C00;color:#FFFFFF">Title</span>
    <nav class="mdl-navigation">
      <a class="mdl-navigation__link"  href="logs.php">Logs view</a>
    </nav>
  </div>
  <main class="mdl-layout__content">
   <div class="page-content">
   <!-- main content -->
   
   <!-- Active Power Viwes. -->
			 <div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone"  align = "center">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
						<font size="4" color= "#FF5722">Active Power</font><div><p id="timesp"></p></div>
					</div>
				</div>
			</div>
			<div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-tablet mdl-cell--0-col-phone"></div>
				<div class="mdl-cell mdl-cell--8-col mdl-cell--10-col-tablet mdl-cell--12-col-phone" style="background-color:#EEEEEE;border-radius:25px" id="chart_div" align="center">
				</div>
			</div>
			
				 <div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone"  align = "center">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
						<font size="4" color= "#FF5722">Reactive Power</font><div><p id="timesp2"></p></div>
					</div>
				</div>
			</div>
			<div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-tablet mdl-cell--0-col-phone"></div>
				<div class="mdl-cell mdl-cell--8-col mdl-cell--10-col-tablet mdl-cell--12-col-phone" style="background-color:#EEEEEE;border-radius:25px" id="chart_div2" align="center">
				</div>
			</div>
			
			 <div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone"  align = "center">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
						<font size="4" color= "#FF5722">Apparent Power</font><div><p id="timesp3"></p></div>
					</div>
				</div>
			</div>
			<div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-tablet mdl-cell--0-col-phone"></div>
				<div class="mdl-cell mdl-cell--8-col mdl-cell--10-col-tablet mdl-cell--12-col-phone" style="background-color:#EEEEEE;border-radius:25px" id="chart_div3" align="center">
				</div>
			</div>
			
					 <div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone"  align = "center">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
						<font size="4" color= "#FF5722">Energy</font><div><p id="timesp4"></p></div>
					</div>
				</div>
			</div>
			<div class="mdl-grid" align="center">
				<div class="mdl-cell mdl-cell--2-col mdl-cell--1-col-tablet mdl-cell--0-col-phone"></div>
				<div class="mdl-cell mdl-cell--8-col mdl-cell--10-col-tablet mdl-cell--12-col-phone" style="background-color:#EEEEEE;border-radius:25px" id="chart_div4" align="center">
				</div>
			</div>
			
			
			
			   <!-- Creadit. -->
			<div class="mdl-grid">
				<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet" align = "center">
					<div class="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet" align = "center">
							<p>This work is in " Voltage level assessment in low voltage distribution networks with high penetration of photovoltaic systems " research project funding by Naresuan University, Thailand, 2015.</p>
							<span>Created by sahakorn ,contract him at <a href="mailto:sahakorn.new@gmail.com?Subject=Hello">sahakorn.new@gmail.com</a> , Under <a href="#">XEUS-LAB</a>.Naresuan University.</span>
							<span>Code under Google, 2015. Licensed under an <a href="https://github.com/google/material-design-lite/blob/master/LICENSE">Apache-2 </a>license.</span>
							<span>Based on <a href ="https://github.com/google/material-design-lite" >Meterial Design</a>. Icons from <a href="http://fortawesome.github.io/Font-Awesome/">Font Awesome</a>. </span>
					</div>
					
				</div>
			</div>
			
		  </div>
  </main>
</div>

</body>
</html>