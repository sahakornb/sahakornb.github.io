     google.charts.load('current', {'packages':['gauge']});
      google.charts.setOnLoadCallback(drawChart);
	  
	  var temp1,temp2,temp3,temp4,temp5,temp6,temp7,temp8,temp9,temp10,temp11,temp12,temp13,temp14,temp15,temp16,temp17,temp18,temp19,temp20; 
	  var interval_num = 5000;
	  function drawChart() {
		
        var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['R  (kW)', Number(temp1) ],
		  ['S  (kW)', Number(temp2) ],
		  ['T (kW)', Number(temp3) ],
		  ['Total (kW)', Number(temp4) ],
        ]);
		
		 var data2 = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
		  ['R  (kVAR)', Number(temp5) ],
		  ['S  (kVAR)', Number(temp6) ],
		  ['T  (kVAR)', Number(temp7) ],
		  ['Total (kVAR)', Number(temp8) ],

        ]);
		
		var data3 = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
		  ['R (kVA)', Number(temp9) ],
		  ['S (kVA)', Number(temp10) ],
		  ['T (kVA)', Number(temp11) ],
		  ['Total (kVA)', Number(temp12) ],
        ]);
			var data4= google.visualization.arrayToDataTable([
          ['Label', 'Value'],
		 ['Energy(kWh)', Number(temp16) ],
        ]);

        var options = {
          width: document.getElementById("chart_div").offsetWidth , height: 300,
          redFrom: 350, redTo: 450,
          yellowFrom:250, yellowTo: 350,max:450,min:0,
          minorTicks: 30
        };

        var chart = new google.visualization.Gauge(document.getElementById('chart_div'));
		var chart2 = new google.visualization.Gauge(document.getElementById('chart_div2'));
		var chart3 = new google.visualization.Gauge(document.getElementById('chart_div3'));
		var chart4 = new google.visualization.Gauge(document.getElementById('chart_div4'));
        chart.draw(data, options);
		chart2.draw(data2, options);
		chart3.draw(data3, options);
		chart4.draw(data4, options);
		
		//Active
        setInterval(function() {
		 // Update data.
		  $.getJSON("http://www.ecpe.nu.ac.th/meter/api.php?key=USA8DD2D&type=recent&addr=1", function(result){
			
			   temp1  = result.data.field1;
			   temp2  = result.data.field2;
			   temp3  = result.data.field3;
			   temp4  = result.data.field4;
			   temp5  = result.data.field5;
			   temp6  = result.data.field6;
			   temp7  = result.data.field7;
			   temp8  = result.data.field8;
			   temp9  = result.data.field9;
			   temp10  = result.data.field10;
			   temp11  = result.data.field11;
			   temp12  = result.data.field12;
			   temp13  = result.data.field13;
			   temp14  = result.data.field14;
			   temp15  = result.data.field15;
			   temp16  = result.data.field16;
			   temp17  = result.data.field17;
			   temp18  = result.data.field18;
			   temp19 = result.data.field19;
			   temp20  = result.data.timesp;
			   
			  $("#timesp").text( temp20 );
			   $("#timesp2").text( temp20 );
			   $("#timesp3").text( temp20 );
			       $("#timesp4").text( temp20 );
			 var data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['R  (kW)', Number(temp1) ],
		  ['S  (kW)', Number(temp2) ],
		  ['T (kW)', Number(temp3) ],
		  ['Total (kW)', Number(temp4) ],
        ]);
		
		 var data2 = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
		  ['R  (kVAR)', Number(temp5) ],
		  ['S  (kVAR)', Number(temp6) ],
		  ['T  (kVAR)', Number(temp7) ],
		  ['Total (kVAR)', Number(temp8) ],

        ]);
		
		var data3 = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
		  ['R (kVA)', Number(temp9) ],
		  ['S (kVA)', Number(temp10) ],
		  ['T (kVA)', Number(temp11) ],
		  ['Total (kVA)', Number(temp12) ],
        ]);
			var data4= google.visualization.arrayToDataTable([
          ['Label', 'Value'],
		 ['Energy(kWh)', Number(temp16) ],
        ]);
		 // Active.
          chart.draw(data, options);
          chart2.draw(data2, options);
          chart3.draw(data3, options);
		  chart4.draw(data4, options);
			});
		  
        }, interval_num);
     
	
		
	  }
	  
	  function getData(){
		  
        $.getJSON("http://www.ecpe.nu.ac.th/meter/api.php?key=USA8DD2D&type=recent&addr=1", function(result){
			
			   temp1  = result.data.field1;
			   temp2  = result.data.field2;
			   temp3  = result.data.field3;
			   temp4  = result.data.field4;
			   temp5  = result.data.field5;
			   temp6  = result.data.field6;
			   temp7  = result.data.field7;
			   temp8  = result.data.field8;
			   temp9  = result.data.field9;
			   temp10  = result.data.field10;
			   temp11  = result.data.field11;
			   temp12  = result.data.field12;
			   temp13  = result.data.field13;
			   temp14  = result.data.field14;
			   temp15  = result.data.field15;
			   temp16  = result.data.field16;
			   temp17  = result.data.field17;
			   temp18  = result.data.field18;
			    temp19 = result.data.field19;
			   temp20  = result.data.timesp;
			  
			  $("#timesp").text( temp20 );
			   $("#timesp2").text( temp20 );
			   $("#timesp3").text( temp20 );
			   $("#timesp4").text( temp20 );
			});
	  }
$(document).ready(function(){
	
	getData();
        });