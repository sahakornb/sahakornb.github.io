<?
	$username = "root";
	$password = "asdf";
	$dbname = "meter";
	$servername = "localhost";
	$public_key = "USA8DD2D";

	
?>