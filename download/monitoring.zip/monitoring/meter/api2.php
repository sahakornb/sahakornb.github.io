<html>
<head>
	<title>Digital Power monitor</title>
	<script src="http://code.jquery.com/jquery-2.0.0.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.1.1.js"></script>
	<link rel="stylesheet" href="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.brown-orange.min.css" />
	 <script src="https://storage.googleapis.com/code.getmdl.io/1.0.6/material.min.js"></script>
	    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<style>

table, th, td {
    border: 1px solid #BCAAA4;
    border-collapse: collapse;
	color:#212121;
	text-align:center;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<?
	require("config.php");
	$act = array();
	
// 	connect to database.
FUNCTION DATABASE_CONNECTION($strSQL) {
	require("config.php");
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

	$sql = "INSERT INTO data (addr, vdc, adc) VALUES (5, 0, 0)";

	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
	$conn->close();
}

FUNCTION INSERT($f1,$f2,$f3,$f4,$f5,$f6,$f7,$f8,$f9,$f10,$f11,$f12,$f13,$f14,$f15,$f16,$f17,$f18){
	require("config.php");
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "INSERT INTO data (field1, field2, field3,field4,field5,field6,field7,field8,field9,field10,field11,field12,field13,field14,field15,field16,field17,field18) VALUES ('$f1','$f2', '$f3',
		'$f4', '$f5','$f6', '$f7', '$f8','$f9', '$f10', '$f11','$f12', '$f13', '$f14','$f15', '$f16','$f17', '$f18')";
	
		if ($conn->query($sql) === TRUE) {
			$act = array('code'=>0,'msg'=>"OK");
			header('Content-Type: application/json');
			echo json_encode($act);
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
			$act = array('code'=>5,'msg'=>'Error: ' . $sql . ',' . $conn->error);
			header('Content-Type: application/json');
			echo  json_encode($act);
		}
$conn->close();
}

FUNCTION UPDATE($addr,$vdc,$adc){
	require("config.php");
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "UPDATE data SET vdc='$vdc',adc = '$adc' WHERE addr='$addr'";

		if ($conn->query($sql) === TRUE) {
			$act = array('code'=>0,'msg'=>"OK");
			header('Content-Type: application/json');
			echo json_encode($act);
		} else {
			$act = array('code'=>5,'msg'=>'Error updating record:'. $conn->error);
			header('Content-Type: application/json');
			echo json_encode($act);
			
		}
		$conn->close();
}
function toTime($date) {
    list($month, $day, $year) = explode('-', $date);
    return mktime(0, 0, 0, $month, $day, $year);
}

function sortByTime($a, $b) {
    $a = toTime($a);
    $b = toTime($b);
    if($a == $b) {
        return 0;
    }
    return $a < $b ? -1 : 1 ;
}
FUNCTION SELECT_DATA1($getDate){
	require("config.php");
		// Create connection
	//	header('Content-Type: application/json');
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM data ORDER BY timesp DESC;";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
    // output data of each row
	
		$data = array();
		$count = 1;
		//echo "<html><head></head><body>";
		echo "<div align='right'><a class='mdl-button mdl-js-button mdl-js-ripple-effect' style='color:#FF5722' href='save_file.php?key=USA8DD2D&type=savefile&flags=1&date=".$getDate."'>SAVE TO FILE</a></div>";
	    echo "<table width='100%' border='1' align='center'>";
		echo "<tr>";
		echo "<th>Time stamp</th>";
		echo "<th>R-Active</th>";
		echo "<th>S-Active</th>";
		echo "<th>T-Active</th>";
		echo "<th>Total-Active</th>";
		echo "<th>R-Reactive</th>";
		echo "<th>S-Reactive</th>";
		echo "<th>T-Reactive</th>";
		echo "<th>Total-Reactive</th>";
		echo "<th>R-Apparent</th>";
		echo "<th>S-Apparent</th>";
		echo "<th>T-Apparent</th>";
		echo "<th>Total-Apparent</th>";
		echo "<th>R-cos</th>";
		echo "<th>S-cos</th>";
		echo "<th>T-cos</th>";
		echo "<th>Energy</th>";
		echo "</tr>";
		$temp_date = "";
		$get_date = array();
	//	echo "</body></html>";
		while($row = $result->fetch_assoc()) {
			$temp= array('field1'=>$row["field1"],'field2'=>$row["field2"],'field3'=>$row["field3"],'field4'=>$row["field4"],'field5'=>$row["field5"],'field6'=>$row["field6"],
			'field7'=>$row["field7"],'field8'=>$row["field8"],'field9'=>$row["field9"],'field10'=>$row["field10"],'field11'=>$row["field11"],'field12'=>$row["field12"],'field13'=>$row["field13"],'field14'=>$row["field14"],
			'field15'=>$row["field15"],'field16'=>$row["field16"],'field17'=>$row["field17"],'field18'=>$row["field18"],'timesp'=>$row["timesp"]);
			$date = date('d-m-Y', strtotime($row["timesp"]));
			if($date == $getDate){
			array_push($data,array($count=>$temp));
		
				echo "<tr>";
					echo "<td>".$row["timesp"]."</td>";
					echo "<td>".$row["field1"]."</td>";
					echo "<td>".$row["field2"]."</td>";
					echo "<td>".$row["field3"]."</td>";
					echo "<td>".$row["field4"]."</td>";
					echo "<td>".$row["field5"]."</td>";
					echo "<td>".$row["field6"]."</td>";
					echo "<td>".$row["field7"]."</td>";
					echo "<td>".$row["field8"]."</td>";
					echo "<td>".$row["field9"]."</td>";
					echo "<td>".$row["field10"]."</td>";
					echo "<td>".$row["field11"]."</td>";
					echo "<td>".$row["field12"]."</td>";
					echo "<td>".$row["field13"]."</td>";
					echo "<td>".$row["field14"]."</td>";
					echo "<td>".$row["field15"]."</td>";
					echo "<td>".$row["field16"]."</td>";
					echo "</tr>";
			$count++;
			}
			else;
			$tempDate = $date;
		}echo "</table>";
			//$act = array('code'=>0,'msg'=>"OK",'data'=>$data);
			//echo json_encode($act);
			//echo $act;
		} else {
				$act = array('code'=>4,'msg'=>'0 result');
				header('Content-Type: application/json');
				echo json_encode($act);
		}
		$conn->close();
}
FUNCTION SELECT($addr){
	require("config.php");
		// Create connection
		header('Content-Type: application/json');
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT DISTINCT timesp FROM data";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
    // output data of each row
	
		$data = array();
		$count = 1;
	
		while($row = $result->fetch_assoc()) {
		//	$act = array('code'=>0,'msg'=>"OK",'data'=>array('field1'=>$row["field1"],'field2'=>$row["field2"],'field3'=>$row["field3"],'field4'=>$row["field4"],'field5'=>$row["field5"],'field6'=>$row["field6"],
			//'field7'=>$row["field7"],'field8'=>$row["field8"],'field9'=>$row["field9"],'field10'=>$row["field10"],'field11'=>$row["field11"],'field12'=>$row["field12"],'field13'=>$row["field13"],'field14'=>$row["field14"],
			//'field15'=>$row["field15"],'field16'=>$row["field16"],'field17'=>$row["field17"],'field18'=>$row["field18"],'timesp'=>$row["timesp"]));
			$date = date('d-m-Y', strtotime($row["timesp"]));
			if($date == $tempDate);
			else{
			array_push($data,array($count=>$date ));
			$count++;
			}
			$tempDate = $date;
		}
		//SELECT_DATA1($date);
		$act = array('code'=>0,'msg'=>"OK",'data'=>$data);
			echo json_encode($act);
		} else {
				$act = array('code'=>4,'msg'=>'0 result');
				header('Content-Type: application/json');
				echo json_encode($act);
		}
		$conn->close();
}


if($_REQUEST['key'] == $public_key)
	{
		if($_REQUEST['type'] == "update")
		{
			if($_REQUEST['addr'] != null && $_REQUEST['vdc'] != null && $_REQUEST['adc'] != null)
				UPDATE($_REQUEST['addr'],$_REQUEST['vdc'],$_REQUEST['adc']);
			else
			{
				$act = array('code'=>3,'msg'=>'Parameter wrong');
				header('Content-Type: application/json');
				echo json_encode($act);
			}
				
		}
		else if($_REQUEST['type'] == "selectdate")
		{
			if($_REQUEST['addr'] != null)
				SELECT($_REQUEST['addr']);
			else
			{
				$act = array('code'=>3,'msg'=>'Parameter wrong');
				header('Content-Type: application/json');
				echo json_encode($act);
			}
			
		}
		else if($_REQUEST['type'] == "selectdata")
		{
			if($_REQUEST['addr'] != null && $_REQUEST['date'] != null)
				SELECT_DATA1($_REQUEST['date']);
			else
			{
				$act = array('code'=>3,'msg'=>'Parameter wrong');
				header('Content-Type: application/json');
				echo json_encode($act);
			}
		}
		else if($_REQUEST['type'] == "insert"){
			if($_REQUEST['field1'] != null)
				
				INSERT($_REQUEST['field1'],$_REQUEST['field2'],$_REQUEST['field3'],$_REQUEST['field4'],$_REQUEST['field5'],$_REQUEST['field6'],
			$_REQUEST['field7'],$_REQUEST['field8'],$_REQUEST['field9'],$_REQUEST['field10'],$_REQUEST['field11'],$_REQUEST['field12'],$_REQUEST['field13'],
			$_REQUEST['field14'],$_REQUEST['field15'],$_REQUEST['field16'],$_REQUEST['field17'],$_REQUEST['field18']);
			else
			{
				$act = array('code'=>2,'msg'=>'No action , type not found!');
			header('Content-Type: application/json');
			echo json_encode($act);
			}
		}
		else if($_REQUEST['type'] == "savefile")
			{
		if($_REQUEST['flags'] == 1 && $_REQUEST['date'] != null)
		{
			SAVEFILE($_REQUEST['date']);
		}
		}
	
		else{
			$act = array('code'=>2,'msg'=>'No action , type not found!');
			header('Content-Type: application/json');
			echo json_encode($act);
		}
	}
	
	
	else
	{
		
		$act = array('code'=>1,'msg'=>'Defined not access , No key found!');
		header('Content-Type: application/json');
		echo json_encode($act);
		
	}
	
?>
</body>
</html>