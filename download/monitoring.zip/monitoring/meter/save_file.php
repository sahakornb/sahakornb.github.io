<?
	require("config.php");
	$act = array();
FUNCTION SAVEFILE($getDate){



require("config.php");
	
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 

		$sql = "SELECT * FROM data";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
	
		$data = array();
		$count = 1;
		$GLOBAL["list"] = array ();
	
	    array_push($GLOBAL["list"],array('Time stamp','R-Active','S-Active','T-Active','Total-Active','R-Reactive','S-Reactive','T-Reactive','Total-Reactive','R-Apparent','S-Apparent','T-Apparent'
		,'Total-Apparent','R-cos','S-cos','T-cos','Energy'));
			$fp = fopen('data_logs/temp.csv', 'w');
		foreach ($GLOBAL["list"] as $fields) {
			fputcsv($fp, $fields);
		}
		fclose($fp);
		$GLOBAL["list"] = array ();
		while($row = $result->fetch_assoc()) 
		{
			$date = date('d-m-Y', strtotime($row["timesp"]));
			if($date == $getDate){
			   array_push($GLOBAL["list"],array($row["timesp"],$row["field1"],$row["field2"],$row["field3"],$row["field4"],$row["field5"],$row["field6"],$row["field7"],$row["field8"],$row["field9"],$row["field10"],$row["field11"]
		,$row["field12"],$row["field13"],$row["field14"],$row["field15"],$row["field16"]));
			}
			else;
			$tempDate = $date;
		}
		$fp1 = fopen('data_logs/temp.csv', 'a');
		foreach ($GLOBAL["list"] as $fields) {
			fputcsv($fp1, $fields);
			
		}
		fclose($fp1);
		header('Location: data_logs/temp.csv');
			//$act = array('code'=>0,'msg'=>"OK",'data'=>$data);
			//echo json_encode($act);
			//echo $act;
		} else {
				$act = array('code'=>4,'msg'=>'0 result');
				header('Content-Type: application/json');
				echo json_encode($act);
		}
		$conn->close();
		
}
if($_REQUEST['key'] == $public_key)
	{

	 if($_REQUEST['type'] == "savefile")
			{
		if($_REQUEST['flags'] == 1 && $_REQUEST['date'] != null)
		{
			SAVEFILE($_REQUEST['date']);
		}
		}
	
		else{
			$act = array('code'=>2,'msg'=>'No action , type not found!');
			header('Content-Type: application/json');
			echo json_encode($act);
		}
	}
	else
	{
		
		$act = array('code'=>1,'msg'=>'Defined not access , No key found!');
		header('Content-Type: application/json');
		echo json_encode($act);
		
	}
?>